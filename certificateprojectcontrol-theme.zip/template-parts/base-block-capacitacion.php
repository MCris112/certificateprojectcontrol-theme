<div class="cpc_card_c mt-5">
            <div class="cpc_card">
                <span class="info_pill">Curso</span>
                <div class="head">
                    <div class="img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/home_card_1.jpg" alt="">
                        <div class="cover"></div>
                    </div>
                    <div class="text">
                        <h3 class="title">Costos y presupuestos alineado al AACE</h3>
                    </div>
                </div>

                <div class="content">
                    <div class="info">
                        <span class="time"><i class="fa fa-clock-o"></i>12 horas</span>
                        <span class="sessions"><i class="fa fa-archive"></i>10:00 a.m</span>
                        <span class="price">$699</span>
                    </div>

                    <a href="" class="btn btn-primary d-block">Ver Curso</a>
                </div>
            </div>

            <div class="cpc_card">
                <span class="info_pill">Curso</span>
                <div class="head">
                    <div class="img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/home_card_1.jpg" alt="">
                        <div class="cover"></div>
                    </div>
                    <div class="text">
                        <h3 class="title">Costos y presupuestos alineado al AACE</h3>
                    </div>
                </div>

                <div class="content">
                    <div class="info">
                        <span class="time"><i class="fa fa-clock-o"></i> 12 horas</span>
                        <span class="sessions"><i class="fa fa-archive"></i> 10:00 AM</span>
                        <span class="price">$699</span>
                    </div>

                    <a href="" class="btn btn-primary d-block">Ver Curso</a>
                </div>
            </div>

            <div class="cpc_card">
                <span class="info_pill">Curso</span>
                <div class="head">
                    <div class="img">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/home_card_1.jpg" alt="">
                        <div class="cover"></div>
                    </div>
                    <div class="text">
                        <h3 class="title">Costos y presupuestos alineado al AACE</h3>
                    </div>
                </div>

                <div class="content">
                    <div class="info">
                        <span class="time"><i class="fa fa-clock-o"></i> 12 horas</span>
                        <span class="sessions"><i class="fa fa-archive"></i> 10:00 AM</span>
                        <span class="price">$699</span>
                    </div>

                    <a href="" class="btn btn-primary d-block">Ver Curso</a>
                </div>
            </div>
        </div>