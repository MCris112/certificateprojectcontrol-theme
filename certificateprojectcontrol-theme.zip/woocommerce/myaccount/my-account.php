<?php

defined('ABSPATH') || exit;

/**
 * My Account navigation.
 */


?>

<?php do_action('woocommerce_account_navigation'); ?>

<div class="container mt-3 mb-3">
	<?php do_action('woocommerce_account_content'); ?>
</div>