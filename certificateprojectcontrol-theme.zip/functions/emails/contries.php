<select class="form-select" aria-label="Default select example" name="cpc_country">
    <option value="AR">Argentina</option>
    <option value="BO">Bolivia</option>
    <option value="BR">Brasil</option>
    <option value="CL">Chile</option>
    <option value="CO">Colombia</option>
    <option value="CR">Costa Rica</option>
    <option value="CU">Cuba</option>
    <option value="EC">Ecuador</option>
    <option value="SV">El Salvador</option>
    <option value="GW">Guayana Francesa</option>
    <option value="GD">Grenada</option>
    <option value="GT">Guatemala</option>
    <option value="GY">Guyana</option>
    <option value="HT">Haiti</option>
    <option value="HN">Honduras</option>
    <option value="MX">México</option>
    <option value="NI">Nicaragua</option>
    <option value="PA">Panamá</option>
    <option value="PY">Paraguay</option>
    <option value="PE">Perú</option>
    <option value="PR">Puerto Rico</option>
    <option value="UY">Uruguay</option>
    <option value="VE">Venezuela</option>
</select>

<?php

//todos los paises latioamericanos en un array (código, pais))

$contries = array(
    'AR' => 'Argentina',
    'BO' => 'Bolivia',
    'BR' => 'Brasil',
    'CL' => 'Chile',
    'CO' => 'Colombia',
    'CR' => 'Costa Rica',
    'CU' => 'Cuba',
    'EC' => 'Ecuador',
    'SV' => 'El Salvador',
    'GW' => 'Guayana Francesa',
    'GD' => 'Grenada',
    'GT' => 'Guatemala',
    'GY' => 'Guyana',
    'HT' => 'Haiti',
    'HN' => 'Honduras',
    'MX' => 'México',
    'NI' => 'Nicaragua',
    'PA' => 'Panamá',
    'PY' => 'Paraguay',
    'PE' => 'Perú',
    'PR' => 'Puerto Rico',
    'DO' => 'República Dominicana',
    'UY' => 'Uruguay',
    'VE' => 'Venezuela',
);

?>